# Corrosion Detection System PCB (PCB1)

This repository contains the schematic and PCB layout files for the corrosion detection system, designed as part of the EDL25 project. The system utilises inductive sensing with a custom PCB coil and the LDC1612 IC, interfaced with the Raspberry Pi Pico. The system tracks corrosion by measuring inductance changes, and an optical USB mouse is used for motion data. Additionally, serial communication is used to exchange data between components.

## Project Overview

The PCB is designed to interface the LDC1612 Inductance-to-Digital Converter (IDC) with the Raspberry Pi Pico and other system components. It includes provisions for a custom planar coil, an interface for the USB optical mouse, and a JST B4B-XH-A connector for connecting external components. Serial communication is employed to transfer data between the Raspberry Pi Pico and external devices.

### Main Components
- **Raspberry Pi Pico** (U2): The microcontroller that processes the data and controls the system. The PCB features a socket to allow easy connection of the Pico.
- **LDC1612**: Inductance-to-Digital Converter, which measures changes in inductance from the custom PCB coil.
- **USB Optical Mouse**: Provides motion data to help track system performance.
- **Custom PCB Coil**: The sensing element that detects changes in inductance caused by corrosion.
- **JST B4B-XH-A Connector**: Provides an external interface for connecting additional components, ensuring secure power and signal connections.
- **Serial Communication Interface**: Used to exchange data between the Raspberry Pi Pico and external devices, facilitating system monitoring and control.

## Folder Structure

The **PCB1** directory contains the following files and folders:

- **Pictures/**: Folder containing images of the PCB layout and 3D renderings:
  - **3D/**: 3D model of the PCB.
  - **Front Copper/**: Front copper layer image.
  - **Bottom Copper/**: Bottom copper layer image.
  
- **Files:**
  - **B4B-XH-A_LF__SN_.kicad_sym**: Custom symbol for the JST B4B-XH-A connector.
  - **B4B-XH-A_LF__SN_.step**: 3D model of the JST B4B-XH-A connector.
  - **JST_B4B-XH-A_LF__SN_.kicad_mod**: Footprint for the JST B4B-XH-A connector.
  - **RASPBERRY_PI_PICO.kicad_mod**: Footprint for the Raspberry Pi Pico.
  - **RASPBERRY_PI_PICO.kicad_sym**: Custom symbol for the Raspberry Pi Pico.
  - **RASPBERRY_PI_PICO.step**: 3D model of the Raspberry Pi Pico.
  - **Readme.md**: This README file.
  - **simplied_pcb.kicad_pcb**: PCB layout file, including component placement and routing.
  - **simplied_pcb.kicad_pro**: KiCad project file.
  - **simplied_pcb.kicad_sch**: Main schematic file for the PCB design.

## How to Use

### 1. Open the Project in KiCad
- Open the `simplied_pcb.kicad_pro` file in **KiCad** (version 6 or 7).

### 2. Review the Schematic and PCB Layout
- Inspect the schematic in **simplied_pcb.kicad_sch** to ensure proper connections for the LDC1612, Raspberry Pi Pico, and custom coil.
- Review the PCB layout in **simplied_pcb.kicad_pcb**, ensuring all components are correctly placed. The layout includes a socket for the Raspberry Pi Pico and a JST B4B-XH-A connector for external connections.

### 3. Modify or Generate Gerber Files
- You can modify the design or directly generate Gerber files for fabrication by selecting **Plot** under the **File** menu in KiCad.

### 4. Solder the Components
- Once the PCB is fabricated, solder the components as per the layout.

### 5. Connect the Raspberry Pi Pico and Other Components
- Insert the **Raspberry Pi Pico** into the provided socket to power the system.
- Solder the custom coil to the designated pads on the PCB.
- Plug in the **USB optical mouse** to the Pico for motion tracking.
- Use the **JST B4B-XH-A connector** for connecting external components securely.
- For data exchange, use the **Serial Communication Interface** to transmit system data between the Raspberry Pi Pico and other devices.

## Requirements

- **KiCad 6 or 7**: To view, modify, and generate files for PCB fabrication.
- **3D Viewer**: To visualize the `.step` models of the PCB and components in KiCad.
- **Soldering Tools**: For assembling the components once the PCB is fabricated.

## Setup

1. Open the project in **KiCad**.
2. Inspect the schematic and PCB layout for correctness.
3. Generate Gerber files for PCB fabrication or make modifications as needed.
4. Assemble the PCB and connect the components.
5. Power up the system by connecting the Raspberry Pi Pico via USB.
6. Set up serial communication for data transfer with external devices.

## Notes

- Ensure that custom symbols and footprints are properly linked in KiCad.
- Double-check the routing of I²C lines (SCL, SDA) and power lines (VCC, GND) for the LDC1612 interface.
- Check the placement of the 3D models if you plan to design an enclosure for the system.

## Future Improvements
- Design additional versions of the PCB with different coil configurations.
- Implement wireless communication for remote monitoring.
- Enhance the system's sensitivity to smaller corrosion levels.




