# Design Process and Tools Used

The mechanical enclosure and sensor housing for the CorroSense device were designed using 3D CAD software to ensure precise alignment of the Raspberry Pi Pico (RP4020), LDC1612 IC and optical encoder module (ZEB-OM115).

 
## Design Tool:
Autodesk Fusion 360 was used for creating and refining the enclosure design.


## Design Process Overview:

**Requirement Analysis:** Based on the dimensions of internal components (PCB coil, optical encoder, Raspberry Pi Pico), the overall size and placement of parts were determined.

**3D Modeling:** Parametric CAD modeling was used to create a modular and compact enclosure that securely holds the components in place.

**Mounting Features:** Screw holes and cutouts were integrated for ease of assembly and sensor alignment without adhesives.

**Exporting:** Final CAD files were exported in .STL format for 3D printing.

**Fabrication:** The parts were printed using PLA material on an Ultimaker 2+ 3D printer with a layer height of 0.2mm.


## Preview:
The STL,OBJ files of the enclosure are included in this folder for visual reference and 3D printing. The pictures of the device after 3D printing is also attached. 
