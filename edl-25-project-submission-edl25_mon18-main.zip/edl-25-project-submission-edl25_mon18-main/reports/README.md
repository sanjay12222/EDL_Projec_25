# MON-18 Milestones

The PDF **MON-18_MILESTONES.pdf** provides detailed information about Milestone 0 through Milestone 4 for the project.

## PDF Contents

The PDF covers the following:

1. **Milestone 0**: Project formation, initial objectives, and proposed solutions.
2. **Milestone 1**: Development of the initial design, methodology, and technical specifications.
3. **Milestone 2**: Implementation of feedback, detailed test plans, and intermediate results.
4. **Milestone 3**: Advanced design, PCB fabrication, and preliminary hardware testing.
5. **Milestone 4**: Final testing, demonstration, and project completion, including key outcomes.

## Key Highlights

- **Problem Statement**: Detecting corrosion under insulated pipelines to prevent industrial accidents.
- **Proposed Solution**: A portable device utilizing PCB planar coils and inductance measurement sensors to map corrosion.
- **Deliverables**: Functional prototype, corrosion detection heatmaps, and detailed testing results.
