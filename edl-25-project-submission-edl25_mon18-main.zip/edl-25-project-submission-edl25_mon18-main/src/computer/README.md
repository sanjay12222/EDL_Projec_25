# Mouse Pixel-to-Centimeter Calibration (`pixel.py`)

This Python script estimates the number of **pixels per centimeter** our mouse travels on screen by capturing two clicks: one at the start and another after moving the mouse **exactly 10 cm**.

## Requirements

- Python 3.x  
- `pynput` library

Install the required package with:

```bash
pip install pynput
```

## How to Use

1. Run the script:

   ```bash
   python mouse_calibration.py
   ```

2. Follow the on-screen instructions:
   - Click **once** at your starting point.
   - Move your mouse physically **10 cm** in a straight line (use a ruler).
   - Click **again**.

3. The script will calculate and display:
   - Pixel distance between the two clicks.
   - Estimated **pixels per centimeter**.

## Example Output

Clicking once at the starting point, then moving mouse exactly 10 cm and click again...
Mouse clicked at (245, 388)
Mouse clicked at (418, 390)

Pixel distance moved: 173.02
Estimated Pixels per cm: 17.30

## Notes

- Ensure the mouse moves in a straight line for better accuracy.
- This tool is helpful for calibrating mouse movement in GUI design, games, or physical-to-digital motion estimation


# Corrosion Detection Script (`FINAL_OUTPUTS.py`)

This script plays a central role in the corrosion detection and mapping system designed for evaluating the condition of metallic pipelines, it's used for showing the **Final outputs** and used in the code **FINAL_OUTPUTS.py**. It integrates sensor data from an **LDC-based inductive sensor** (e.g., LDC1612) and positional feedback from an **optical mouse sensor** (e.g., ZEB-OM115), enabling **real-time 2D/3D visualization** of corrosion intensity on the pipeline surface.


### Key Features

- **Serial Communication with Arduino**: Reads real-time corrosion level data via a serial port (COM7 by default).
- **Mouse-based Positional Tracking**: Tracks relative movement using an optical sensor to estimate scanning path and position.
- **Corrosion Mapping and Visualization**:
  - Interpolates measured data and generates a **3D surface plot** showing corrosion intensity.
  - Generates a **2D heatmap with contours** to visualize distribution clearly.
- **Mouse-Coil Distance Compensation**: Applies a horizontal correction offset to align sensor data with real-world coil position.
- **Simulation Mode**: If no Arduino is connected, the script can simulate data, making it easy to test plotting and logic.
- **Audio Feedback**: Plays an audible beep when “High Corrosion” is detected (Windows only via `winsound`).
- **Data Logging**: Saves scan results (`X, Y, Corrosion`) to a timestamped `.txt` file.


### How It Works

1. **Serial Setup**: Tries to establish connection to `COM7` (can be changed in the script).
2. **Threaded Serial Reading**: A background thread constantly monitors the incoming corrosion data from the sensor.
3. **Automated Data Collection**: Simulates a scanning motion and collects data at defined grid positions.
4. **Real-Time Alerts**: On detecting high corrosion, it immediately notifies the user via sound and console message.
5. **Data Interpolation & Plotting**:
   - Raw data points are interpolated using `scipy.griddata`.
   - Both 3D surface and 2D contour plots are generated using `matplotlib`.
6. **Result Storage**: Once scanning is done, results are saved locally for future analysis.


### Dependencies

- `pynput` – for mouse input (used for extensions)
- `matplotlib` – for plotting 2D and 3D graphs
- `scipy` – for grid interpolation
- `numpy` – for numerical operations
- `serial` (`pyserial`) – for communication with Arduino
- `winsound` – for audio alert on Windows (optional)

Install with:

```bash
pip install pyserial pynput matplotlib scipy numpy

