# Import the mouse module from the pynput library to listen to mouse events
from pynput import mouse

# Create an empty list to store the coordinates of mouse clicks
positions = []

# Define a callback function that gets called on mouse click
def on_click(x, y, button, pressed):
    if pressed:
        # Store the coordinates of the click
        positions.append((x, y))
        print(f"Mouse clicked at ({x}, {y})")
        # Stop listening after two clicks
        if len(positions) == 2:
            return False  # This stops the listener

# Prompt the user to click twice: once at the start, then after moving the mouse 10 cm
print("Click once at the starting point, then move mouse exactly 10 cm and click again...")

# Start listening to mouse click events using the Listener context manager
with mouse.Listener(on_click=on_click) as listener:
    listener.join()  # Wait until the listener is stopped (after two clicks)

# After the listener has stopped, calculate the distance between the two points
if len(positions) == 2:
    # Unpack the coordinates
    x1, y1 = positions[0]
    x2, y2 = positions[1]
    # Calculate the difference in x and y directions
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    # Use Pythagoras' theorem to get the Euclidean distance in pixels
    distance_pixels = (dx**2 + dy**2)**0.5
    # Since the user moved the mouse exactly 10 cm, compute pixels per cm
    pixels_per_cm = distance_pixels / 10
    # Display the results
    print(f"\nPixel distance moved: {distance_pixels:.2f}")
    print(f"Estimated Pixels per cm: {pixels_per_cm:.2f}")
else:
    # In case fewer than 2 clicks were registered
    print("Failed to capture two points.")
