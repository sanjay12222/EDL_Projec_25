# Import necessary libraries
from pynput import mouse  # To handle mouse events
import matplotlib.pyplot as plt  # For creating plots
from mpl_toolkits.mplot3d import Axes3D  # For 3D plotting
import serial  # For serial communication
import time  # To manage time-related tasks
import threading  # To run multiple threads concurrently
import numpy as np  # For numerical operations
from scipy.interpolate import griddata  # For interpolation in 2D/3D plots
import winsound  # For playing a beep sound on Windows

# --- Setup Serial Communication ---
try:
    # Try establishing a serial connection on COM7 at 9600 baud rate
    ser = serial.Serial('COM7', 9600, timeout=1)
    time.sleep(2)  # Give time for the serial connection to establish
    print("Serial connection established on COM7")
except Exception as e:
    # If there's an error, print the message and set ser to None (simulation mode)
    print(f"Error connecting to serial port: {e}")
    ser = None  # Allow the program to run in simulation mode if serial isn't available

# --- Global Variables ---
positions = []  # List to store positions (x, y)
corrosions = []  # List to store corrosion levels corresponding to each position
latest_corrosion = "UNKNOWN"  # To store the latest corrosion level
latest_position = (0, 0)  # Default starting position of the scan
lock = threading.Lock()  # Lock for thread-safe data updates
data_ready = threading.Event()  # Event to signal when data collection is done
origin = (0, 0)  # Default origin point (0, 0)
PIXELS_PER_CM = 18  # Conversion factor: 18 pixels per cm (for scaling)
MOUSE_COIL_DISTANCE_CM = 5.5  # Distance between mouse and sensor coil in cm
X_CORRECTION = MOUSE_COIL_DISTANCE_CM * PIXELS_PER_CM  # Apply correction factor to X-axis

# --- Corrosion Levels Mapping ---
corrosion_levels = {
    "No Corrosion": 0,  # No corrosion level
    "Low Corrosion": 1,  # Low corrosion level
    "Moderate Corrosion": 2,  # Moderate corrosion level
    "High Corrosion": 3,  # High corrosion level
    "UNKNOWN": -1  # Placeholder for unknown corrosion level
}

# --- Background Thread to Read Arduino Data ---
def read_serial():
    global latest_corrosion  # Access global variable to store corrosion levels
    
    if ser is None:  # If no serial connection, print a message and return
        print("Serial connection not available. Running in simulation mode.")
        return
        
    while True:
        try:
            # Read a line of data from the serial port and decode it
            line = ser.readline().decode('utf-8').strip()
            if "Corrosion:" in line:  # Check if line contains corrosion data
                level = line.split("Corrosion:")[1].strip()  # Extract corrosion level
                
                # Lock the access to latest_corrosion for thread-safety
                with lock:
                    latest_corrosion = level
                    
                # If high corrosion is detected, play a beep sound
                if level == "High Corrosion":
                    winsound.Beep(1000, 500)  # Frequency: 1000Hz, Duration: 500ms
                    print(" HIGH CORROSION DETECTED! ")
                    
        except Exception as e:
            # Handle any errors during serial reading
            print(f"Serial read error: {e}")
            time.sleep(0.1)  # Wait briefly before retrying
            continue

# --- Auto Data Collection ---
def collect_data():
    global positions, corrosions  # Access global variables for storing data
    
    print("Starting automatic data collection. Collecting 30 points...")
    print(f"Using X correction of {X_CORRECTION} pixels ({MOUSE_COIL_DISTANCE_CM} cm)")
    
    # Add simulated data points (replace with real sensor data in actual application)
    for i in range(30):
        # Simulate scanning pattern (left to right, top to bottom)
        x = (i % 10) * 30  # 10 points per row, 30 pixels apart
        y = (i // 10) * 30  # 3 rows, 30 pixels apart
        
        # Apply X-axis correction to account for mouse-coil distance
        rel_x = x - X_CORRECTION
        rel_y = y
        
        time.sleep(0.5)  # Simulate a delay between readings
        
        # In simulation mode, randomly generate corrosion levels
        if ser is None:
            corrosion_options = list(corrosion_levels.keys())[:-1]  # Exclude 'UNKNOWN'
            corrosion = np.random.choice(corrosion_options)
            
            # Simulate a pattern: higher corrosion near the center
            distance_from_center = np.sqrt((rel_x - 0)**2 + (rel_y - 60)**2)
            if distance_from_center < 50:
                corrosion = "High Corrosion"
            elif distance_from_center < 100:
                corrosion = "Moderate Corrosion"
            elif distance_from_center < 150:
                corrosion = "Low Corrosion"
            else:
                corrosion = "No Corrosion"
            
            # Play beep for high corrosion in simulation mode too
            if corrosion == "High Corrosion":
                winsound.Beep(1000, 500)
                print(" HIGH CORROSION DETECTED! ")
        else:
            # In real mode, use the latest corrosion level from the serial data
            with lock:
                corrosion = latest_corrosion
            
        # Output the current point data to the console
        print(f"Point {i+1}/30: Position ({rel_x}, {rel_y}) | Corrosion: {corrosion}")
        positions.append((rel_x, rel_y))  # Append position to positions list
        corrosions.append(corrosion)  # Append corrosion level to corrosions list
    
    # Signal that data collection is complete
    data_ready.set()
    print("Data collection complete.")

# --- Create and Display 3D Surface Plot and 2D Heatmap ---
def create_plots():
    # Wait for data collection to finish before plotting
    data_ready.wait()
    
    # Convert corrosion levels to numerical values for plotting
    z_vals = [corrosion_levels.get(c, -1) for c in corrosions]
    x_vals, y_vals = zip(*positions)  # Unzip positions into x and y values
    
    # Create a grid for the surface plot
    xi = np.linspace(min(x_vals), max(x_vals), 100)  # X-axis grid points
    yi = np.linspace(min(y_vals), max(y_vals), 100)  # Y-axis grid points
    X, Y = np.meshgrid(xi, yi)  # Create a 2D grid
    
    # Interpolate the corrosion levels (z values) on the grid
    Z = griddata((x_vals, y_vals), z_vals, (X, Y), method='cubic', fill_value=0)
    
    # Create figure with two subplots (3D plot and heatmap)
    fig = plt.figure(figsize=(15, 7))
    
    # --- 3D Surface Plot ---
    ax1 = fig.add_subplot(121, projection='3d')
    
    # Plot the 3D surface
    surf = ax1.plot_surface(X, Y, Z, cmap='hot', edgecolor='none', alpha=0.8)
    
    # Add scatter points for actual data
    scatter = ax1.scatter(x_vals, y_vals, z_vals, c=z_vals, cmap='hot', s=50, edgecolor='k')
    
    # Add colorbar
    cbar1 = fig.colorbar(surf, ax=ax1, shrink=0.5, aspect=5, label='Corrosion Intensity')
    cbar1.set_ticks(list(corrosion_levels.values())[:-1])  # Exclude 'UNKNOWN'
    cbar1.set_ticklabels(list(corrosion_levels.keys())[:-1])  # Exclude 'UNKNOWN'
    
    # Set labels and title
    ax1.set_xlabel('X (pixels, corrected)')
    ax1.set_ylabel('Y (pixels)')
    ax1.set_zlabel('Corrosion Level')
    ax1.set_title('3D Corrosion Map')
    
    # Annotate mouse and coil positions
    min_x = min(x_vals)
    max_x = max(x_vals)
    mid_y = np.mean(y_vals)
    min_z = min(z_vals)
    ax1.text(min_x, mid_y, min_z, "coil", color='blue', fontsize=12)
    ax1.text(max_x, mid_y, min_z, "mouse", color='red', fontsize=12)
    
    # Adjust view angle for better visualization
    ax1.view_init(elev=30, azim=45)
    
    # --- 2D Heatmap Plot ---
    ax2 = fig.add_subplot(122)
    
    # Create heatmap for the 2D view
    heatmap = ax2.contourf(X, Y, Z, levels=20, cmap='hot')
    
    # Add scatter points for actual data on the heatmap
    scatter = ax2.scatter(x_vals, y_vals, c=z_vals, cmap='hot', s=50, edgecolor='k')
    
    # Add colorbar to heatmap
    cbar2 = fig.colorbar(heatmap, ax=ax2, label='Corrosion Intensity')
    cbar2.set_ticks(list(corrosion_levels.values())[:-1])  # Exclude 'UNKNOWN'
    cbar2.set_ticklabels(list(corrosion_levels.keys())[:-1])  # Exclude 'UNKNOWN'
    
    # Set labels and title for heatmap
    ax2.set_xlabel('X (pixels, corrected)')
    ax2.set_ylabel('Y (pixels)')
    ax2.set_title('2D Corrosion Heatmap')
    
    # Annotate mouse and coil positions on heatmap
    ax2.text(min_x, mid_y, "coil", color='blue', fontsize=12, ha='center')
    ax2.text(max_x, mid_y, "mouse", color='red', fontsize=12, ha='center')
    
    # Add contour lines to heatmap for clearer visualization
    contour = ax2.contour(X, Y, Z, levels=4, colors='black', linewidths=0.5, alpha=0.7)
    ax2.clabel(contour, inline=True, fontsize=8)
    
    # Shared figure title and additional information
    plt.suptitle('Corrosion Detection Mapping', fontsize=16)
    plt.figtext(0.5, 0.01, f"Mouse-Coil Distance: {MOUSE_COIL_DISTANCE_CM} cm ({X_CORRECTION} pixels)", 
                fontsize=10, ha='center')
    
    # Adjust layout for a clean look
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])  # Ensure space for title
    plt.show()

# --- Optional: Save Results to File ---
def save_results():
    data_ready.wait()  # Wait for data collection to complete
    
    # Create a list of collected data (positions and corrosion levels)
    data = []
    for (x, y), corr in zip(positions, corrosions):
        data.append([x, y, corr])
    
    # Save the data to a timestamped text file
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    filename = f"corrosion_scan_{timestamp}.txt"
    
    with open(filename, 'w') as f:
        f.write("X,Y,Corrosion\n")  # Write header
        for x, y, corr in data:  # Write each data point
            f.write(f"{x},{y},{corr}\n")
    
    print(f"Results saved to {filename}")

# --- Main Function ---
def main():
    print("Corrosion Detection System Starting...")
    print("Features: 3D Surface Plot, 2D Heatmap, and High Corrosion Audio Alert")
    
    # Start the serial reading in a separate thread
    serial_thread = threading.Thread(target=read_serial, daemon=True)
    serial_thread.start()

    # Start data collection in a separate thread
    collection_thread = threading.Thread(target=collect_data, daemon=True)
    collection_thread.start()

    # Optional: Start saving results in a separate thread
    save_thread = threading.Thread(target=save_results, daemon=True)
    save_thread.start()

    # Start creating plots after data collection is complete
    create_plots()

    # Keep the main thread alive until the plot window is closed
    try:
        plt.show()
    except KeyboardInterrupt:
        print("Program terminated by user")
    finally:
        # Cleanly close the serial connection when the program ends
        if ser and ser.is_open:
            ser.close()
            print("Serial connection closed")

# Run the main function when the script is executed
if __name__ == "__main__":
    main()
