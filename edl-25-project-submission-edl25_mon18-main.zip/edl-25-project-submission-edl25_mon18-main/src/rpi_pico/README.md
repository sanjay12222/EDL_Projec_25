# Reference Inductance Measurement and Corrosion Detection

This project involves using the Raspberry Pi Pico to measure corrosion levels on metallic surfaces by utilizing the Seeed LDC1612 inductive sensor. The system works by detecting changes in inductance as a result of corrosion, allowing for the estimation of corrosion severity. The project also includes a separate program to measure the reference inductance for calibration purposes.

## Table of Contents

- [Microcontroller Model](#microcontroller-model)
- [Required Hardware](#required-hardware)
- [Setup Instructions](#setup-instructions)
- [Code Overview](#code-overview)
  - [Reference Inductance Code](#reference-inductance-code)
  - [Main Corrosion Detection Code](#main-corrosion-detection-code)
- [Uploading Code](#uploading-code)
- [Testing the Code](#testing-the-code)
- [Output Description](#output-description)

## Microcontroller Model

- **Raspberry Pi Pico (RP2040)**

## Required Hardware

- Raspberry Pi Pico (RP2040)
- Seeed LDC1612 Inductive Sensor
- Jumper Wires for I2C connection
- A clean, non-corroded metallic surface for reference measurements

## Setup Instructions

1. **Install Raspberry Pi Pico Support in Arduino IDE**:
   - Open **Arduino IDE**.
   - Go to **File > Preferences**.
   - In the "Additional Boards Manager URLs" field, add the following URL:
     ```
     https://github.com/earlephilhower/arduino-pico/releases/download/global/package_rp2040_index.json
     ```
   - Go to **Tools > Board > Board Manager**.
   - Search for **Raspberry Pi RP2040** and install the package.

2. **Select Board and Port**:
   - Go to **Tools > Board > Raspberry Pi Pico**.
   - Select the correct **Port** (it should appear once the Pico is connected).

## Code Overview
This project consists of two separate pieces of code:

### Reference Inductance Code  
This code is used to calibrate the sensor by measuring the inductance of a clean, non-corroded metallic surface. The measured value serves as a **reference inductance**, which is later used in **Main Corrosion Detection code** to detect and classify corrosion.

#### Key Variables:
- **`NUM_SAMPLES`**  
  Number of sensor readings taken for averaging. A higher value improves accuracy and reduces noise in the inductance measurement.

- **`SENSOR_CAPACITANCE`**  
  The known capacitor value in the LC circuit. It is fixed at **1000 pF (picofarads)** and is used in the formula to calculate inductance from frequency readings.


### Main Corrosion Detection Code  
This code uses the LDC1612 sensor to detect corrosion levels by comparing real-time inductance values to the calibrated reference value. It estimates height and determines corrosion severity based on ΔL (inductance difference).

#### Key Variables:
- **`SENSOR_CAPACITANCE`**  
  Same as above—fixed at **1000 pF**, used in the LC resonance formula.

- **`REF_INDUCTANCE`**  
  The baseline inductance value measured from a clean, non-corroded sample. Used for comparison. (In our case: **573.25 nH**)

- **`MIN_VALID_FREQUENCY`** and **`MAX_VALID_FREQUENCY`**  
  Frequency limits used to estimate the distance between the sensor and the surface. These help determine if the sample is within measurable range.

- **`FREQ_SLOPE`** and **`FREQ_INTERCEPT`**  
  Constants used to linearly map frequency readings to height estimates.

- **`LOW_THRESHOLD`**, **`MODERATE_THRESHOLD`**, **`HIGH_THRESHOLD`**  
  ΔL (inductance difference) thresholds used to classify the corrosion as:
  - No Corrosion
  - Low Corrosion
  - Moderate Corrosion
  - High Corrosion


## Uploading Code

1. **Open Arduino IDE** and create a new sketch for each code.
2. **Copy and Paste** the respective code into the new sketch.

   - For **Reference Inductance Code**, use the code provided in the `REFERENCE_INDUCTANCE_OF_NON_CORRODED_SURFACE.ino`.
   - For **Main Corrosion Detection Code**, use the code provided in the `MAIN_CORROSION_DETECTION.ino`.

3. **Select the Correct Board and Port**:
   - In **Tools > Board**, select **Raspberry Pi Pico**.
   - In **Tools > Port**, select the correct port for your Raspberry Pi Pico.

4. **Upload the Code**:
   - Click the **Upload** button (the right arrow icon in the Arduino IDE).
   - Wait for the upload process to complete. You should see a "Done uploading" message in the status bar.

## Testing the Code

After uploading the code, open the **Serial Monitor** in the Arduino IDE (Ctrl + Shift + M or **Tools > Serial Monitor**).

- **Reference Inductance of non-corroded surface Code**: The system will print the reference inductance after placing the LDC sensor coil over a clean, non-corroded surface.
- **Main Corrosion Detection Code**: You will see data about the estimated height, frequency, and corrosion classification (No Corrosion, Low Corrosion, Moderate Corrosion, High Corrosion).

## Output Description


### Reference Inductance Code Output:
- **Inductance (nH)**: The calculated inductance for each sample, followed by the final averaged reference inductance.

Example:
Sample 1: Inductance = 580.1 nH Sample 2: Inductance = 582.3 nH ... Final Reference Inductance (L_REF): 580.9 nH

### Main Corrosion Detection Code Output:
- **Height**: Estimated height of the surface in mm.
- **Frequency**: The raw frequency measured by the LDC1612 sensor.
- **ΔL**: The difference in inductance compared to the reference value (in nH).
- **Corrosion**: A classification of the corrosion level (No Corrosion, Low Corrosion, Moderate Corrosion, High Corrosion).

Example:
Height: 1.2 mm | Freq: 6.5 MHz | ΔL: 1.2 nH | Corrosion: Low Corrosion

