# FINAL HEATMAPS SHOWED IN THE DEMO VIDEO

The collected inductance and position data from the **CorroSense** device (**after scanning our device over the surface shown in demo video**) is post-processed to generate heatmaps and 3D surface plots (**in VSCode**) that visually represent the intensity and location of corrosion on metallic surfaces. By combining data from the LDC1612 inductance sensor and the ZEB-OM115 optical encoder, this project provides an intuitive visualization of corrosion levels, helping in the detection and analysis of corrosion patterns.

## Visual Results

The corrosion detection results are presented in two visual formats in the uploaded heatmap picture (**HEATMAP.jpeg**)

### Left: 3D Corrosion Map

This 3D surface plot visualizes corrosion intensity as elevation.

- **X and Y Axes**: Represent the corrected spatial positions (in pixels) as tracked by the optical encoder.
- **Z-Axis**: The height indicates the relative corrosion level, derived from the inductance drop measured by the LDC1612 sensor.
- **Peaks (yellow)**: High corrosion.
- **Valleys (dark red/black)**: Low to no corrosion.

#### Key Features:
- **Coil Position**: Labeled "coil," corresponding to the sensing area.
- **Encoder Path**: Shown with black dots to indicate the movement path.

### Right: 2D Corrosion Heatmap

This heatmap is a top-down view of the corrosion data, color-coded based on corrosion intensity.

- **Color Gradient**:
  - **Black**: No corrosion
  - **Red**: Low corrosion
  - **Orange**: Moderate corrosion
  - **Yellow**: High corrosion
- The color gradient quickly helps identify areas with varying corrosion levels.

#### Key Features:
- **Black Dots**: Mark the encoder’s movement path.
- **Mouse-Coil Distance**: Displayed below the heatmap, indicating the offset between the sensor and encoder module for calibration.
